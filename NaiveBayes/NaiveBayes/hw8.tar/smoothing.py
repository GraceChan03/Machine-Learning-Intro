from nb import NB
import sys

if __name__ == '__main__':
    NB(sys.argv[1], sys.argv[2], float(sys.argv[3]))